
import Data.mongo_setup as mongo_setup
import Service.data_service as svc
import login
#import admin

def main():
    mongo_setup.global_init()
    print('Hello, welcome to the engineering shop sign in system alpha. ')


    try:
        while True:
            if find_user_intent() == 'log':
                login.run()
            else:
                print("-------------------- NOT IMPLEMENTED ----------------------")
            rule = input("\n Exit? [y/n]\n")
            if rule == 'y':
                break


    except KeyboardInterrupt:
        return

def find_user_intent():
    choice = input('\n Would you like to [l]ogin or perform an administrative action? \n')
    if choice == 'l':
        return 'log'



if __name__ == '__main__':
    main()

