import datetime
import mongoengine




class Student(mongoengine.Document):
    registered_date = mongoengine.DateTimeField(default=datetime.datetime.now)
    name = mongoengine.StringField(required=True)
    
    studentID = mongoengine.StringField(required=True)
    Is_signedIn = mongoengine.BooleanField(default=False)


    def event(self):


        self.Is_signedIn = not self.Is_signedIn
        self.save()

    meta = {
        'db_alias': 'core',
        'collection': 'Students'
    }
