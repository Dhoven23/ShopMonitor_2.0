import mongoengine
import datetime

class Signin(mongoengine.Document):

    signins = mongoengine.ListField()