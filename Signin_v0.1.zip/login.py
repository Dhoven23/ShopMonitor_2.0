import Service.data_service as svc


def login():
    svc.log_into_account()


def run():

    login()





