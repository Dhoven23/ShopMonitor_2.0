
import datetime

import bson

import Service.Infrastructure as state
from Data.Students import Student
from Data.signins import Signin





def create_student(name: str, studentID: str) -> Student:
    student = Student()
    student.name = name
    student.studentID = studentID

    student.save()

    return student

def log_into_account():
    while True:
        print(' ****************** LOGIN **************** ')

        studentID = input('What is your Student ID?    ([q] to exit): \n').strip().lower()
        if studentID == 'q':
            break
        student = find_student_by_studentID(studentID)


        if not student:
            print(f'Cound not find student with ID {studentID}.')
            name = input('\n Please enter your first and last name: \n')
            student = create_student(name,studentID)

        SignedIn = student.Is_signedIn
        if SignedIn == False:
            print(f"\n Hello {student.name} \n")
            student.event()

        if SignedIn == True:
            print(f"\n Goodbye {student.name} \n")
            student.event()









def find_student_by_studentID(studentID: int) -> Student:
    student = Student.objects(studentID=studentID).first()
    return student
