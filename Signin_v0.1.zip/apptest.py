import sys

# 1. Import `QApplication` and all the required widgets
from PyQt4 import QtGui



